const { bosses } = require('../datasets/bosses');

const bossPrompts = {
  // Create an array of objects that each have the name of the boss and the sum loyalty of all their sidekicks.
  // ex: [
  //   { bossName: 'Jafar', sidekickLoyalty: 3 },
  //   { bossName: 'Ursula', sidekickLoyalty: 20 },
  //   { bossName: 'Scar', sidekickLoyalty: 16 }
  // ]
  bossLoyalty() {

  }
};

module.exports = bossPrompts;
