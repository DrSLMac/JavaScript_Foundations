const clubs = [
  { club: 'Drama', members: ['Louisa', 'Pam', 'Nathaniel' ] },
  { club: 'Band', members: ['Leta', 'Robbie', 'Jhun', 'Will'] },
  { club: 'Chess', members: ['David', 'Pam', 'Brittany', 'Robbie'] },
  { club: 'Newspaper', members: ['Pam', 'David', 'Brittany', 'Christie', 'Leta'] },
  { club: 'Astronomy', members: ['Nathaniel', 'Leta'] },
  { club: 'FBLA', members: ['Christie', 'David', 'Robbie'] },
  { club: 'Art', members: ['Jhun', 'Louisa'] }
];

module.exports = {
  clubs
};