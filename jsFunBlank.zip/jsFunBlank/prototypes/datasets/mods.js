const mods = [
  { mod: 1, students: 27, instructors: 3 },
  { mod: 2, students: 33, instructors: 3 },
  { mod: 3, students: 20, instructors: 2 },
  { mod: 4, students: 16, instructors: 2 }
];

module.exports = {
  mods
};