const classrooms = [
  { roomLetter: 'A', program: 'FE', capacity: 32 },
  { roomLetter: 'B', program: 'BE', capacity: 29 },
  { roomLetter: 'C', program: 'FE', capacity: 27 },
  { roomLetter: 'D', program: 'BE', capacity: 30 },
  { roomLetter: 'E', program: 'FE', capacity: 22 },
  { roomLetter: 'F', program: 'BE', capacity: 19 },
  { roomLetter: 'G', program: 'FE', capacity: 29 },
  { roomLetter: 'H', program: 'BE', capacity: 18 }
];

module.exports = {
  classrooms
};