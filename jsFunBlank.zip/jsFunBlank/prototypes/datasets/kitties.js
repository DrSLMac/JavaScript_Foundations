const kitties = [
  {
    name: 'Felicia',
    age: 2,
    color: 'grey'
  },
  {
    name: 'Tiger',
    age: 5,
    color: 'orange'
  },
  {
    name: 'Snickers',
    age: 8,
    color: 'orange'
  },
  {
    name: 'Max',
    age: 1,
    color: 'tuxedo'
  }
];

module.exports = {
  kitties
}