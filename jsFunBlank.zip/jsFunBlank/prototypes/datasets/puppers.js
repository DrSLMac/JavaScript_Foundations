const puppers = [
  {
    name: 'Scout',
    age: 12,
    color: 'grey'
  },
  {
    name: 'Hatchet',
    age: 3,
    color: 'orange'
  },
  {
    name: 'Stick',
    age: 6,
    color: 'brown'
  },
  {
    name: 'Butter',
    age: 1,
    color: 'orange'
  }
];

module.exports = {
  puppers
}